package fpi.paymentrun;

public enum InnovatorSetup {

    PLUGINS_APP,
    PLUGINS_APP_TWO,
    PLUGINS_SCA_APP,
    PLUGINS_WEBHOOKS_APP,
    PLUGINS_SCA_MA_APP
}
