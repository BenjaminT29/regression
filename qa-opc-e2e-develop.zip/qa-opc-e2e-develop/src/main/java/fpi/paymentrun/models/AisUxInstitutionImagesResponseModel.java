package fpi.paymentrun.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AisUxInstitutionImagesResponseModel {
    private String logo;
    private String icon;
}
