package fpi.paymentrun.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AisUxInstitutionInfoResponseModel {
    private String loginUrl;
    private String helplinePhoneNumber;
}
