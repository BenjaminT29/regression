package opc.helpers;

public class OpenBankingKeys {

    public static final String CLIENT_PRIVATE_KEY =
            "-----BEGIN PRIVATE KEY-----\n" +
                    "MIIEvwIBADANBgkqhkiG9w0BAQEFAASCBKkwggSlAgEAAoIBAQDmcY8MUOvM8XI/\n" +
                    "UaCbUGwB/Co3j/nz/PDHH9GVn17FJx4uCrAP7cMZcbYWdzGOVzWYyfwYsCqKtAjg\n" +
                    "9vMyFtcSjT4Mu4FrsvHYScq1DHlHDjXYwi+g1y3CRZchWukT9xQRrKuEAtM3aC0r\n" +
                    "oihWmTJUDEhgqOjfFIu3mEHj6vbOfLTi7guoEU8uTB68aUNcGbfVAteEFmSi9bwM\n" +
                    "4B8chKHpq+9sUXiQU44Aw5Rf5TMI4U9gbLWQutiyO+YU1R1bivrlHPOP10QewQqd\n" +
                    "kAIxggFi+iABdSBLljpwpMdudzzgLaVUqug2BnboeIAxv1gN2GaO59Smd5jBbgi3\n" +
                    "w4q9oWQLAgMBAAECggEBAK6Dq0A5fAlthAa9q3JTeigarmH7j+AdWr6BszerRJrr\n" +
                    "n+hgQasedRSsz6e9xnK0SquVs2uC5gS6iMrNWalCMMgk3KvJyB4mmw4f+/oWIzYT\n" +
                    "ZeXsUSNuMYIhL22cKkzrXXBxIkbL2Obp5uNXX1MNm1aZIqrI3+oo5hI4pRWUmCoQ\n" +
                    "SP/PgTFnjaHm1nIx+u2pTVI42GCflC0YCfKmGL3dkedb1zVeIRk3qBTtLIooz6rM\n" +
                    "O8t1ZG1t2E3JbatKDS5Us7uBRsas6i2d0xRYExU5Ep9/LYojRPxq/rg83fJvIJ2E\n" +
                    "U1XXX8nfWrGR/hvxVqr5tms4Pp4NBPeP++Qu3cCeRcECgYEA91NCf+/52wXFF0IP\n" +
                    "OwLhuhQdC5OA/rQ7P+zvm9oc+xVCJCKSsbmDI0hi0u2C7heNnloszKPjbvbrxqlr\n" +
                    "YazFXeRattiJ3vvpqlVqjIbe46Sf8kEfQrF27zLgZgcxOUa7FDAUOSuPTnSCkbfB\n" +
                    "OkyVlKQP4wLtgMGSSsNcPP9zBSsCgYEA7oa336A3Wy+OM8kaVHExNV11pur8wFrp\n" +
                    "onDEJBqEFYml/a+74sNaoC+McSuL3BTKBQe/6w5t6+76QQlBpwxoK1/2DGqIAHP7\n" +
                    "m6Exw7t7jKjhWH1KtpfbooUMbrxHLfWTeJWiYQYbLSxJKexwANEJnsKPjnKbUlQ6\n" +
                    "pzuI1ivXbKECgYBCB9eUQqSJZiP1jqx0S9OqE16hzZK97a535bEfAf+ExWswLI7P\n" +
                    "pkCttdC0kbbIDD/CDD8zr3m0EXZnRqolnLPg2muhr3Q3tTfwQve8ZvGxAy20xtAq\n" +
                    "xSiEuieQ9dCdgxXFUQTFMq0C/DYz40RSZUn2MksPh6OTIZsGHNxOaMDzmwKBgQCX\n" +
                    "OkSz/LF8F7+R56vQ498uFW41gQD0t+8u9U32EfWybg4WtGdsEy2PJ/Zj/hbzVx7q\n" +
                    "Z4pvbjuU/XQe7c55Ke2VqoamQpitqNtaRa32ihSADsaowu8uq0MuXCqQvsBmTC/O\n" +
                    "oRhNaYCreEt+0BAHBIGT7Yj06Ia/gPWa96z/FNbFYQKBgQCe0BHPNE3qEcLi6BwF\n" +
                    "DWYpL3k1/aITwQ58NBQMCl6Mi+DJmrM3NtuRBip+aWxKTGqCdMf/PKkIl0eusgcU\n" +
                    "CTWRX5T4X57kPEqZvFrn9RLVyYq5SX2JkE/eZKAi2ZOiLpS83EeoP4TxCc90GZUf\n" +
                    "3d2USxteMnYkJOrs5mNnscnVOA==\n" +
                    "-----END PRIVATE KEY-----";

    public final static String CLIENT_CERTIFICATE =
            "MIIDaDCCAlACCQC+dGzo0mW1HTANBgkqhkiG9w0BAQUFADB1MRowGAYDVQQKDBFF" +
                    "bmFibGUgQmFua2luZyBPeTEOMAwGA1UEBwwFRXNwb28xCzAJBgNVBAYTAkZJMR4w" +
                    "HAYDVQRhDBVQU0RGSS1GSU5GU0EtMjk4ODQ5OTcxGjAYBgNVBAMMEWVuYWJsZWJh" +
                    "bmtpbmcuY29tMCAXDTIxMDkxMzA5MzM0OVoYDzIxMjEwODIwMDkzMzQ5WjB1MRow" +
                    "GAYDVQQKDBFFbmFibGUgQmFua2luZyBPeTEOMAwGA1UEBwwFRXNwb28xCzAJBgNV" +
                    "BAYTAkZJMR4wHAYDVQRhDBVQU0RGSS1GSU5GU0EtMjk4ODQ5OTcxGjAYBgNVBAMM" +
                    "EWVuYWJsZWJhbmtpbmcuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKC" +
                    "AQEA5nGPDFDrzPFyP1Ggm1BsAfwqN4/58/zwxx/RlZ9exSceLgqwD+3DGXG2Fncx" +
                    "jlc1mMn8GLAqirQI4PbzMhbXEo0+DLuBa7Lx2EnKtQx5Rw412MIvoNctwkWXIVrp" +
                    "E/cUEayrhALTN2gtK6IoVpkyVAxIYKjo3xSLt5hB4+r2zny04u4LqBFPLkwevGlD" +
                    "XBm31QLXhBZkovW8DOAfHISh6avvbFF4kFOOAMOUX+UzCOFPYGy1kLrYsjvmFNUd" +
                    "W4r65Rzzj9dEHsEKnZACMYIBYvogAXUgS5Y6cKTHbnc84C2lVKroNgZ26HiAMb9Y" +
                    "DdhmjufUpneYwW4It8OKvaFkCwIDAQABMA0GCSqGSIb3DQEBBQUAA4IBAQC+M5KG" +
                    "ZiYW6Tb/Bh/I4OTA52kwYOT35vaLRpJ5Rg5lbukunUkWv2ultSZImHL4JlyuCbK1" +
                    "NqcV3jQih5RBvTx6dNnt20l2pPuDdqIx0wHq6yL++VbAHCYlXqpGSzmCsmjvYvIt" +
                    "48ZiMDf3t9JPqL+K2Tm4Okku/cyNnZNCpFkX5HnAMt16yytJLW6BANx01Vg63lyF" +
                    "It7G09skZLl97Fma6ZdbMUQp+Y0/o0wZc6FYsVOw5mHl6Q73x61CoknohoB1nEoQ" +
                    "s79zDCpuvYV0yhj35LCe1+O/GiwNHdXgP46nWNb7sDm/NjS90MzS+R8mabMoxi+2" +
                    "KBsSOZNGhNAE10Y0";
}
