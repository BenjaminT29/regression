package opc.models.innovator;

public class SecretTypesModel {

    private String firstSecretType;

    public String getFirstSecretType() {
        return firstSecretType;
    }

    public SecretTypesModel setFirstSecretType(String firstSecretType) {
        this.firstSecretType = firstSecretType;
        return this;
    }
}
