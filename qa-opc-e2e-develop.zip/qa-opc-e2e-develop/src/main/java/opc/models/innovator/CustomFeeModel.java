package opc.models.innovator;

public class CustomFeeModel {
}
