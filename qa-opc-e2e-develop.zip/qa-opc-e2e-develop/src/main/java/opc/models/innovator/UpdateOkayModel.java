package opc.models.innovator;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UpdateOkayModel {
  private final String firebaseKey;
}
