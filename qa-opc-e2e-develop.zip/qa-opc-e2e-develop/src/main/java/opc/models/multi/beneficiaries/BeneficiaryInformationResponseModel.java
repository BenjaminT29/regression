package opc.models.multi.beneficiaries;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BeneficiaryInformationResponseModel {

    private String businessName;
    private String fullName;
}
