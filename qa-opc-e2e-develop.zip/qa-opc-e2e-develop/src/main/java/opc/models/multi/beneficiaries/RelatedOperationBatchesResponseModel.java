package opc.models.multi.beneficiaries;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RelatedOperationBatchesResponseModel {

    private String batchId;
    private String operation;
}
