package opc.models.admin;

public class SubscriberIdModel {

    private String type;
    private String id;

    public String getType() {
        return type;
    }

    public String getId() {
        return id;
    }
}
