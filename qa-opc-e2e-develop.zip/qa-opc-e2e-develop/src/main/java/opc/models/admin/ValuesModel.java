package opc.models.admin;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValuesModel {
    private ValueModel[] values;
}
