package opc.models.admin;

import java.util.List;

public class SubscriptionsResponseModel {

    private List<SubscribersModel> subscribers;

    public List<SubscribersModel> getSubscribers() {
        return subscribers;
    }
}
