package opc.models.admin;

public class RemainingLimitsResponseModel {
}
