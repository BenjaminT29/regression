package opc.models.admin;

import opc.models.shared.TypeIdResponseModel;

public class CorporateRootUserResponseModel {
    private String id;
    private String type;
    private TypeIdResponseModel identity;
    private String username;
    private String title;
    private String name;
    private String surname;
    private String email;
    private boolean active;
    private String companyPosition;
    private String mobileCountryCode;
    private String mobileNumber;
    private DateOfBirthResponseModel dateOfBirth;
    private String beneficiaryId;
    private boolean permanentlyClosed;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public TypeIdResponseModel getIdentity() {
        return identity;
    }

    public void setIdentity(TypeIdResponseModel identity) {
        this.identity = identity;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCompanyPosition() {
        return companyPosition;
    }

    public void setCompanyPosition(String companyPosition) {
        this.companyPosition = companyPosition;
    }

    public String getMobileCountryCode() {
        return mobileCountryCode;
    }

    public void setMobileCountryCode(String mobileCountryCode) {
        this.mobileCountryCode = mobileCountryCode;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public DateOfBirthResponseModel getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(DateOfBirthResponseModel dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getBeneficiaryId() {
        return beneficiaryId;
    }

    public void setBeneficiaryId(String beneficiaryId) {
        this.beneficiaryId = beneficiaryId;
    }

    public boolean getPermanentlyClosed() {
        return permanentlyClosed;
    }

    public void setPermanentlyClosed(boolean permanentlyClosed) {
        this.permanentlyClosed = permanentlyClosed;
    }

}
