package opc.models.admin;

public class SubscriptionsModel {

    private String serviceProviderKey;
    private String status;

    public String getServiceProviderKey() {
        return serviceProviderKey;
    }

    public String getStatus() {
        return status;
    }
}
