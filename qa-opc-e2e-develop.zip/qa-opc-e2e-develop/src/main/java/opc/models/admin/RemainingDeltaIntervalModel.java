package opc.models.admin;

public class RemainingDeltaIntervalModel {

    private String tumbling;

    public String getTumbling() {
        return tumbling;
    }

    public RemainingDeltaIntervalModel setTumbling(String tumbling) {
        this.tumbling = tumbling;
        return this;
    }
}
