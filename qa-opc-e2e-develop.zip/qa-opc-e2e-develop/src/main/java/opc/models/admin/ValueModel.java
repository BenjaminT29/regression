package opc.models.admin;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValueModel {
    private String name;
    private String value;
}
