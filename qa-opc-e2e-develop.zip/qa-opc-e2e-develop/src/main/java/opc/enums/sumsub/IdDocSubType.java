package opc.enums.sumsub;

public enum IdDocSubType {

    FRONT_SIDE,
    BACK_SIDE
}
