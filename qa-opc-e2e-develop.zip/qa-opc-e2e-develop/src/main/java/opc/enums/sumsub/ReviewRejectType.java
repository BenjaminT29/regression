package opc.enums.sumsub;

public enum ReviewRejectType {

    RETRY,
    EXTERNAL,
    FINAL
}
