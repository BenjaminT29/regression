package opc.enums.sumsub;

public enum SumSubApplicantState {

    completed,
    pending
}
