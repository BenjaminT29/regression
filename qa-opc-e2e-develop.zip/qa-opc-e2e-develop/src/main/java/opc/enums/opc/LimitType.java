package opc.enums.opc;

public enum LimitType {
    VELOCITY,
    CUMULATIVE
}
