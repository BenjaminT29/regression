package opc.enums.opc;

public enum DestroyedReason {
    SYSTEM,
    USER,
    LOST,
    STOLEN,
    EXPIRED
}
