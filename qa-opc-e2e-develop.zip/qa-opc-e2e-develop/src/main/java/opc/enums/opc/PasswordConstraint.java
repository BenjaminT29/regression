package opc.enums.opc;

public enum PasswordConstraint {
    PASSWORD,
    PASSCODE,
    // Test Enum
    UNKNOWN
}
