package opc.enums.opc;

public enum UserType {
    ROOT,
    USER,
    ADMIN
}
