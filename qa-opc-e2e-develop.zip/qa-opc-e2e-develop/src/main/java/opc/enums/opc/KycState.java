package opc.enums.opc;

public enum KycState {
    NOT_STARTED,
    INITIATED,
    APPROVED,
    PENDING_REVIEW,
    REJECTED
}