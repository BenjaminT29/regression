package opc.enums.opc;

public enum OwtType {
    SEPA,
    FASTER_PAYMENTS,
    SWIFT
}
