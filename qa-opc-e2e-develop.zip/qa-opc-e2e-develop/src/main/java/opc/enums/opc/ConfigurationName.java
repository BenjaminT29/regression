package opc.enums.opc;

public enum ConfigurationName {

    MANAGED_CARDS
}
