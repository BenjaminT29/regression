package opc.enums.opc;

public enum KycLevel {

    KYC_LEVEL_1,
    KYC_LEVEL_2
}
