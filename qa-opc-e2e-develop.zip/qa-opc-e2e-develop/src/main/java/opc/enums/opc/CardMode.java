package opc.enums.opc;

public enum CardMode {

    DEBIT,
    PREPAID
}
