package opc.enums.opc;

public enum KybLevel {
    FULL_KYB_CHECK;
}
