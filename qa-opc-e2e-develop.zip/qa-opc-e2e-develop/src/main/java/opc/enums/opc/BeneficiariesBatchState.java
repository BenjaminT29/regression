package opc.enums.opc;

public enum BeneficiariesBatchState {
  INITIALISED,
  FAILED,
  PENDING_CHALLENGE,
  CHALLENGE_FAILED,
  CHALLENGE_COMPLETED,
  COMPLETED
}