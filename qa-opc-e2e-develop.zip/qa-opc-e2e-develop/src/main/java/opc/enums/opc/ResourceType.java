package opc.enums.opc;

public enum ResourceType {
  OUTGOING_WIRE_TRANSFERS,
  SENDS,
  VARIABLE_RECURRING_PAYMENTS
}
