package opc.enums.opc;

public enum DepositType {

    SEPA,
    FASTER_PAYMENTS
}
