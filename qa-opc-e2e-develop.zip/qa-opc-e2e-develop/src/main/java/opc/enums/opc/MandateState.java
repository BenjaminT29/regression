package opc.enums.opc;

public enum MandateState {

    ACTIVE,
    CANCELLED,
    EXPIRED,

    // Used for test purposes
    UNKNOWN
}
