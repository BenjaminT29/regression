package opc.enums.opc;

public enum ReplacementType {
    DAMAGED,
    LOST_STOLEN,
    RENEW
}
