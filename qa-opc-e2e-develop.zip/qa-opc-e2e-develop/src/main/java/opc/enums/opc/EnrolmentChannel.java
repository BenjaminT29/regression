package opc.enums.opc;

public enum EnrolmentChannel {
  EMAIL,
  SMS,
  AUTHY,
  BIOMETRIC,

  // Used for testing purposes
  UNKNOWN
}
