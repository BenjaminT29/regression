package opc.enums.opc;

public enum ManufacturingState {
    REQUESTED,
    DELIVERED
}
