package opc.enums.opc;

public enum EmiLicenseHolder {
    NON_EMI,
    WEAVR_UK,
    WEAVR_EU
}