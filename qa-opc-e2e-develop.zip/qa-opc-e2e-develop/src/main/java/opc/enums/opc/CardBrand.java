package opc.enums.opc;

public enum CardBrand {
    MASTERCARD,
    VISA
}
