package opc.enums.opc;

public enum ManagedCardMode {
    DEBIT_MODE,
    PREPAID_MODE
}
