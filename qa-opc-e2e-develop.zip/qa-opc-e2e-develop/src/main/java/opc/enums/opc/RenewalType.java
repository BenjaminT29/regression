package opc.enums.opc;

public enum RenewalType {
    AUTO_RENEW,
    ASK,
    NO_RENEW
}
