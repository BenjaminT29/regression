package opc.enums.opc;

public enum IdentityDeactivateReasons {

    ACCOUNT_REVIEW,
    ACCOUNT_SECURITY,
    TEMPORARY,
    ACCOUNT_CLOSURE,
    ACCOUNT_ABANDONED

}
