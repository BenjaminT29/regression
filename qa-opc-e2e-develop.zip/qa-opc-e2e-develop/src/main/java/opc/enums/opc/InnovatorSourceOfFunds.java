package opc.enums.opc;

public enum InnovatorSourceOfFunds {
    LABOUR_CONTRACT
}
