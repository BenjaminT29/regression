package opc.enums.opc;

public enum SecurityModelConfiguration {
    CVV,
    CARD_NUMBER,
    PASSWORD,
    PIN
}
