package opc.enums.opc;

public enum CardModeThirdPartyRegistry {
    DEBIT_MODE,
    PREPAID_MODE;
}
