package opc.enums.opc;

public enum ManagedAccountState {

    CREATED,
    UPDATED,
    BLOCKED,
    UNBLOCKED,
    DESTROYED,
    REQUESTED
}
