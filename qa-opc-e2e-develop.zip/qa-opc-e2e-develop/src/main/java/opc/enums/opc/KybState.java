package opc.enums.opc;

public enum KybState {
    NOT_STARTED,
    INITIATED,
    APPROVED,
    PENDING_REVIEW,
    REJECTED
}
