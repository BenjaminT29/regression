package opc.enums.opc;

public enum RetryType {
    RETRY,
    FORCE_NO_LOSS,
    FORCE_LOSS,
    RETRY_WITH_IMPROVEMENT
}
