package opc.enums.opc;

public enum DefaultTimeoutDecision {
    APPROVE,
    DECLINE
}