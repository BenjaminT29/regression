package opc.enums.opc;

public enum BlockedReason {
    USER,
    SYSTEM,
    LOST
}
