package opc.enums.opc;

public enum CannedResponseType {
    UNDEFINED,
    SUCCESS,
    FAILURE,
    UNKNOWN_SUCCESS,
    MISSING,
    UNKNOWN_FAILURE
}
