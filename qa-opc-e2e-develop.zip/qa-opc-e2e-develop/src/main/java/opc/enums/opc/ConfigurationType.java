package opc.enums.opc;

public enum ConfigurationType {

    MANAGED_CARD_TOKENISATION_ENABLED,
    MANAGED_CARD_DIGITAL_WALLET_ARTWORK
}
