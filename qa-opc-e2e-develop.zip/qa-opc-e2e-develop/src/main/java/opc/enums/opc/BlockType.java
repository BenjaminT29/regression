package opc.enums.opc;

public enum BlockType {

    VELOCITY,
    USER,
    ACCOUNT,
    ADMIN
}
