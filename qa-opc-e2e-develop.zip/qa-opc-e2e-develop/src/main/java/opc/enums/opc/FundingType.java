package opc.enums.opc;

public enum FundingType {

    DEBIT,
    PREPAID
}
