package opc.enums.opc;

public enum CardholderPresent {
    PRESENT,
    NOT_PRESENT
}
