package opc.enums.openbanking;

public enum TppSignatureComponent {
    KEY_ID,
    ALGORITHM,
    HEADERS,
    SIGNATURE
}