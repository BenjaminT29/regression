package opc.enums.openbanking;

public enum PaymentState {

    AUTHORISED,
    PENDING_CHALLENGE
}
