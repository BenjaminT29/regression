package opc.database;

import java.sql.Connection;

public class BaseDatabaseExtension {

    public static Connection DB_CONNECTION;
}
