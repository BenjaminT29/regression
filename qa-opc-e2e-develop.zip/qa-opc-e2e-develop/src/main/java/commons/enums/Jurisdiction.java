package commons.enums;

public enum Jurisdiction {

    EEA,
    UK
}
