package commons.enums;

public enum Roles {
    CREATOR,
    CONTROLLER,
    ADMIN
}
