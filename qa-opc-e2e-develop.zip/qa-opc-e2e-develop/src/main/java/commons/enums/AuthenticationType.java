package commons.enums;

public enum AuthenticationType {

    PASSWORD,
    PASSCODE,
    COMPLEX_PASSWORD
}
