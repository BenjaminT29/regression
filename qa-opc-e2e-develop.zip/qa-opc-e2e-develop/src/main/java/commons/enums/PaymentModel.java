package commons.enums;

public enum PaymentModel {

    DEFAULT_QA,
    DEFAULT_PAYMENT_RUN
}
